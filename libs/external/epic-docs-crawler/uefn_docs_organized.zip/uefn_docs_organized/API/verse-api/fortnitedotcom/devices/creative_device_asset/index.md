# creative_device_asset class

> **来源**: https://dev.epicgames.com/documentation/en-us/fortnite/verse-api/fortnitedotcom/devices/creative_device_asset
> **爬取时间**: 2025-12-27T01:40:24.915249

---

Internal asset for representing creative devices.

|  |  |
| --- | --- |
| Verse `using` statement | `using { /Fortnite.com/Devices }` |

## Members

This class has no members.
