# creative_prop_asset class

> **来源**: https://dev.epicgames.com/documentation/en-us/fortnite/verse-api/fortnitedotcom/devices/creative_prop_asset
> **爬取时间**: 2025-12-27T01:58:03.742780

---

Asset used to spawn `creative_prop` instances.

|  |  |
| --- | --- |
| Verse `using` statement | `using { /Fortnite.com/Devices }` |

## Members

This class has no members.
