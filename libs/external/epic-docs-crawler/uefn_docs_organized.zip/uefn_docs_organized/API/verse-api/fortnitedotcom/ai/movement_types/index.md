# movement_types module

> **来源**: https://dev.epicgames.com/documentation/en-us/fortnite/verse-api/fortnitedotcom/ai/movement_types
> **爬取时间**: 2025-12-27T00:59:33.000982

---

Module import path: /Fortnite.com/AI/movement\_types

- [`Fortnite.com`](/documentation/en-us/fortnite/verse-api/fortnitedotcom)
- [`AI`](/documentation/en-us/fortnite/verse-api/fortnitedotcom/ai)
- **`movement_types`**

## Data

| Name | Description |
| --- | --- |
| `Walking` |  |

|  |  |
| --- | --- |
| `Running` |  |
