# navigation_target class

> **来源**: https://dev.epicgames.com/documentation/en-us/fortnite/verse-api/fortnitedotcom/ai/navigation_target
> **爬取时间**: 2025-12-27T00:59:00.030362

---

|  |  |
| --- | --- |
| Verse `using` statement | `using { /Fortnite.com/AI }` |

## Members

This class has no members.
